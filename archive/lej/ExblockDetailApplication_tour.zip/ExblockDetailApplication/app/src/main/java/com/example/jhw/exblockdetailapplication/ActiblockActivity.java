package com.example.jhw.exblockdetailapplication;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class ActiblockActivity extends BaseActivity {

    @BindView(R.id.vertical_recycler_view)
    RecyclerView mRecyclerView;

    private HashMap<String,HorizonRepo>[] horizontalList;
    private ArrayList<HorizonRepo> verticalList;

    private LinearLayoutManager layoutManager;
    private VerticalRecyclerAdapter mAdapter;

    private int responseCount;
    private String TmapapiKey;
    private String TourapiKey;
    private GpsTracker gpsTracker;

    private static final int MIDDLE_ADD_REQUEST_CODE = 3000;
    private static final int MIDDLE_ALTER_REQUEST_CODE = 3001;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_actiblock);
        ButterKnife.bind(this);
        TmapapiKey = getMetadata(this, "com.example.jhw.TmapKey");
        TourapiKey = getString(R.string.tour_api_key);
        showWaitingDialog();

        // 0 : 숙박, 1 : 음식점, 2 : 레저 3 : 축제
        horizontalList = new HashMap[4];
        for (int i = 0; i < horizontalList.length; i++) {
            horizontalList[i] = new HashMap<>();
        }

        gpsTracker = new GpsTracker(ActiblockActivity.this);
        getData();
    }

    private void init() {

        verticalList = new ArrayList<>();
        verticalList.add(null);
        verticalList.add(new HorizonRepo(0,"숙박",horizontalList[0].get("숙박").getPoiList(),1));
        verticalList.add(new HorizonRepo(1,"TV맛집",horizontalList[1].get("TV맛집").getPoiList(),2));
        verticalList.add(new HorizonRepo(2,"놀거리",horizontalList[2].get("놀거리").getPoiList(),3));
        verticalList.add(new HorizonRepo(3,"축제",horizontalList[3].get("축제").getPoiList(),4));

        mAdapter = new VerticalRecyclerAdapter(verticalList);
        layoutManager = new LinearLayoutManager(this);
        mRecyclerView.setHasFixedSize(true); // 성능 개선
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setAdapter(mAdapter);
        mAdapter.setOnClickListener(new VerticalRecyclerAdapter.OnClickListener() {
            @Override
            public void onItemClick(View view, int position) {
                switch (view.getId()) {
                    case R.id.add_block:
                        Intent intent = new Intent(ActiblockActivity.this, MiddleblockActivity.class);
                        intent.putExtra("addposition", position);
                        intent.putExtra("list", horizontalList);
                        startActivityForResult(intent, MIDDLE_ADD_REQUEST_CODE);
                        break;
                    case R.id.del_block:
                        verticalList.remove(position);
                        mAdapter.notifyItemRemoved(position);
                        break;
                    default:
                        Toast.makeText(getApplicationContext(), "default " + position, Toast.LENGTH_SHORT).show();
                        break;
                }
            }
        });
        mAdapter.setOnClick2Listener(new VerticalRecyclerAdapter.OnClick2Listener() {
            @Override
            public void onItem2Click(HorizonRepo horizonRepo) {
                Intent intent = new Intent(ActiblockActivity.this, MiddleblockActivity.class);
                intent.putExtra("horizonrepo", horizonRepo);
                intent.putExtra("list", horizontalList);
                startActivityForResult(intent, MIDDLE_ALTER_REQUEST_CODE);
            }
        });
        cancelWaitingDialog();
    }

    private void getData() {
        responseCount = 1;
        getPOI("숙박", 0);
     //   getPOI("호텔", 0);
        getPOI("TV맛집", 1);
  //      getPOI("한식", 1);
   //     getPOI("중식", 1);
  //     getPOI("양식", 1);
   //     getPOI("치킨", 1);
        getPOI("놀거리", 2);
 //       getPOI("레저", 2);
   //     getPOI("레저", 2);
    //    getPOI("영화관", 2);
     //   getPOI("노래방", 2);
        getTourAPI("축제",3);
    }

    private void getPOI(String category, int index) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(RetrofitExService.Tmap_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class);
        Call<JsonObject> call = retrofitExService.getPOIData(1, 1, 20, category, gpsTracker.longitude, gpsTracker.latitude, 10, TmapapiKey);
        Log.d("poiget", "getPOI: " + call.request().toString());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    Log.d("poiget", "getPOI: !!");
                    JsonObject searchPoiInfo = response.body();
                    JsonArray poiList = searchPoiInfo.get("searchPoiInfo").getAsJsonObject().get("pois").getAsJsonObject().get("poi").getAsJsonArray();
                    ArrayList<PoiRepo> poiArray = new ArrayList<>();

                    for (JsonElement poi : poiList) {

                        String poiId = poi.getAsJsonObject().get("id").getAsString();
                        String placeName = poi.getAsJsonObject().get("name").getAsString();
                        String telNo = poi.getAsJsonObject().get("telNo").getAsString();
                        double lat = poi.getAsJsonObject().get("noorLat").getAsDouble();
                        double lon = poi.getAsJsonObject().get("noorLon").getAsDouble();
                        StringBuilder address = new StringBuilder();
                        address.append(poi.getAsJsonObject().get("upperAddrName").getAsString() + " ");
                        address.append(poi.getAsJsonObject().get("middleAddrName").getAsString() + " ");
                        address.append(poi.getAsJsonObject().get("lowerAddrName").getAsString() + " ");
                        address.append(poi.getAsJsonObject().get("roadName").getAsString() + " ");
                        address.append(poi.getAsJsonObject().get("buildingNo1").getAsString());
                        String buildingNo2 = poi.getAsJsonObject().get("buildingNo2").getAsString();
                        if (!(buildingNo2.equals("0") || buildingNo2.equals("")))
                            address.append(buildingNo2);
                        if (placeName.contains("주차장") || placeName.contains("정문") || placeName.contains("후문")) continue;
                        if(category.equals("숙박") && placeName.contains("호텔")) continue;
                        if(category.equals("놀거리") && placeName.contains("노래")) continue;
                        Log.d("poiget", "getPOI: " + address);
                        Log.d("poiget", "getPOI: " + placeName + ", index" + index);
                        poiArray.add(new PoiRepo(poiId, placeName, telNo, address.toString(), lat, lon));
                    }
                    horizontalList[index].put(category, new HorizonRepo(index,category,poiArray));
                    if (responseCount >= 4) init();
                    else responseCount++;
                }
            }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("getData fail", "======================================");
            }
        });
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK) {
            switch (requestCode) {
                case MIDDLE_ADD_REQUEST_CODE:
                    HorizonRepo addHorizonRepo = (HorizonRepo) data.getSerializableExtra("returnHR");
                    int addPosition = addHorizonRepo.getvIndex();
                    verticalList.add(addPosition,addHorizonRepo);
                    mAdapter.notifyItemInserted(addPosition);
                    break;
                case MIDDLE_ALTER_REQUEST_CODE:
                    HorizonRepo alterHorizonRepo = (HorizonRepo) data.getSerializableExtra("returnHR");
                    int alterPosition = alterHorizonRepo.getvIndex();
                    verticalList.set(alterPosition,alterHorizonRepo);
                    mAdapter.notifyItemChanged(alterPosition);
                    break;
            }
        }
    }

    private void getTourAPI(String category, int index) {
        long now = System.currentTimeMillis();
        Date date = new Date(now);
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String getTime = sdf.format(date);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(RetrofitExService.Tour_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        RetrofitExService retrofitExService = retrofit.create(RetrofitExService.class);
        Call<JsonObject> call = retrofitExService.getTourApi("oQCXdkrLI3yLcKih6dtV1QeH5XKwa0hXf9mUZH3RwMsUBjBxBa6ruEMxyLkK7bxcY2KbfkYcQvhpHeY9CXjUCw%3D%3D", 1, 1, "AND", "WHEWHIGO", "C", "Y", "json");
        Log.d("tourrrr", "getTourAPI: "+call.request().toString());
        call.enqueue(new Callback<JsonObject>() {
            @Override
            public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
                if (response.isSuccessful()) {
                    Log.d("poiget", "getPOI: !!");
                    JsonObject searchTourAPI = response.body();
                    JsonArray apiList = searchTourAPI.get("response").getAsJsonObject().get("body").getAsJsonObject().get("items").getAsJsonObject().get("item").getAsJsonArray();
                    ArrayList<PoiRepo> apiArray = new ArrayList<>();

                    for (JsonElement item : apiList) {

                        String title = item.getAsJsonObject().get("title").getAsString();
                        String addr1 = item.getAsJsonObject().get("addr1").getAsString();
                        String tel = item.getAsJsonObject().get("tel").getAsString();
                        long eventstartdate = item.getAsJsonObject().get("eventstardate").getAsLong();
                        long eventenddate = item.getAsJsonObject().get("eventenddate").getAsLong();
                        double mapx = item.getAsJsonObject().get("mapx").getAsDouble();
                        double mapy = item.getAsJsonObject().get("mapy").getAsDouble();
                        apiArray.add(new PoiRepo(title, addr1, tel, mapx, mapy,eventstartdate,eventenddate));
                    }
                    horizontalList[index].put(category, new HorizonRepo(index,category,apiArray));
                    if (responseCount >= 4) init();
                    else responseCount++;
                }

        retrofit.create(RetrofitExService.class);
    }

            @Override
            public void onFailure(Call<JsonObject> call, Throwable t) {
                Log.e("getData fail", "======================================");
            }
            });
    }
}