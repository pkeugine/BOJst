package com.example.jhw.exblockdetailapplication;

public class TourDetail {
    private String title;
    private String addr;
    private String tel;
    private String eventStartDate;
    private String eventEndDate;

    public TourDetail(String title, String addr, String tel, String eventStartDate, String eventEndDate) {
        this.title = title;
        this.addr = addr;
        this.tel = tel;
        this.eventStartDate = eventStartDate;
        this.eventEndDate = eventEndDate;
    }

    public String getTitle() { return title; }
    public String getAddr() { return addr; }
    public String getTel() { return tel; }
    public String getEventStartDate() { return eventStartDate; }
    public String getEventEndDate() { return eventEndDate; }

}
