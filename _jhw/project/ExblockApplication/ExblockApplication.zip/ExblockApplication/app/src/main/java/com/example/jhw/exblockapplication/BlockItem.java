package com.example.jhw.exblockapplication;

public class BlockItem {
    private String name;

    public BlockItem() {}
    public BlockItem(String name) {
        this.name = name;
    }


    public String getName() {
        return this.name;
    }
    public void setName(String name) {
        this.name = name;
    }

}
