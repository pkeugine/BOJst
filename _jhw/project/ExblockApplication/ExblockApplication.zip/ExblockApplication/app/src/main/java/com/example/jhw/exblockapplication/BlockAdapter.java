package com.example.jhw.exblockapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

public class BlockAdapter extends RecyclerView.Adapter<BlockAdapter.ViewHolder> {

    private ArrayList<BlockItem> mData = null;
    //private Context mContext = null;
    //private OnItemClickListener mListener = null;

    public BlockAdapter(ArrayList<BlockItem> list) {
        mData = list;
//      mContext = context;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView name;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            name = itemView.findViewById(R.id.name);
        }
    }


    @NonNull
    @Override
    public BlockAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        Context context = viewGroup.getContext();
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View view = inflater.inflate(R.layout.block_item,viewGroup,false);
        ViewHolder vh = new ViewHolder(view);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull BlockAdapter.ViewHolder viewHolder, int i) {
        BlockItem item = mData.get(i);
        viewHolder.name.setText(item.getName());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }
}
